var testpath= "taketest.html";
var allreportpath= "allreport.html";
var reportpath= "reportsample.html";
var videopath= "videocard.html";
var url= "http://192.168.1.201:8000/gettest";
