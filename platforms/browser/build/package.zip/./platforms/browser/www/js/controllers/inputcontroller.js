
app.controller('inputController', function($scope,$http, $location,$localStorage) {


	
	$scope.mark = [
		{image: 'assets/images/bak.jpg',testno:01,description:'Test Description',questions:3,totalmarks:2},
		{image: 'assets/images/bak.jpg',testno:02,description:'Test Description',questions:4,totalmarks:2}
	];
	

});	