angular
.module('loginapp', ['ngMaterial', 'ngMessages','ngCordova'])
.controller('Videologincontroller',Videologincontroller);
function Videologincontroller($scope,$location,$timeout,$cordovaFileTransfer) {
	
	
  	document.addEventListener("deviceready", onDeviceReady, false);
	var i=0,tid=0;
	var test_id;
	var video_id=new Array();
	var video_path=new Array();
	$scope.progress = true;
	
	
	function onDeviceReady(){
		
		
		
		
		$scope.login=function login(){
			if ( $scope.Name == "test" && $scope.Password == "test")
			{
		
				//alert("fj");
					
				//abc();
				window.location = "navbar.html";
			}
			else{
				$scope.errormsg="Invalid Name or Password";
				// alert("wrong");
				// alert($scope.Password);
			}
		};
		
	
	}
	
};