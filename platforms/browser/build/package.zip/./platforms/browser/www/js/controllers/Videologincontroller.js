angular
  .module('loginapp', ['ngMaterial', 'ngMessages'])
  .controller('Videologincontroller', function($scope,$location) {
  
   $scope.login=function login(){
     if ( $scope.Name == "test" && $scope.Password == "test")
	 {
	 window.location = "navbar.html";	
	 }
	 else{
	 $scope.errormsg="Invalid UserName or Password";
		 // alert("wrong");
		 // alert($scope.Password);
	 }

  }
 });